<?php
return array(
    //添加模板变量规则
	
    'TMPL_PARSE_STRING'=>array(
        'CSS' =>__ROOT__.'/Public/Css',
        'JS' =>__ROOT__.'/Public/Js',
        'IMG' =>__ROOT__.'/Public/Images',
        'PLUG' =>__ROOT__.'/Public/Plugins',
        'FONT' =>__ROOT__.'/Public/Font',
        'ASSETS' =>__ROOT__.'/Public/assets',
    	'ZTREEBASE' =>__ROOT__.'/Public/ztree',
    ),



);