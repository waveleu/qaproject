<?php if (!defined('THINK_PATH')) exit();?>﻿<!DOCTYPE html>
<html>
<head lang="en">
    <title>Login Page</title>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" href="/qaweb/Public/ztree/css/demo.css" type="text/css">
    <link rel="stylesheet" href="/qaweb/Public/ztree/css/awesomeStyle/awesome.css" type="text/css">
    <script type="text/javascript" src="/qaweb/Public/assets/js/jquery-1.8.3.min.js"></script>
    <link rel="icon" type="image/png" href="/qaweb/Public/assets/i/favicon.png">
    <link rel="apple-touch-icon-precomposed" href="/qaweb/Public/assets/i/app-icon72x72@2x.png">
    <link rel="stylesheet" href="/qaweb/Public/assets/css/amazeui.min.css"/>
    <link rel="stylesheet" href="/qaweb/Public/assets/css/admin.css">
    <style>
        .header {
            text-align: center;
        }
        .header h1 {
            font-size: 200%;
            color: #333;
            margin-top: 30px;
        }
        .header p {
            font-size: 14px;
        }

    </style>
</head>

<body >
<div class="header">
    <div class="am-g">
        <h1><img src="/qaweb/Public/Images/logo.png"> </h1>
        <h1 style="color: #BF2126;">QA Web System</h1>
    </div>
</div >
<div class="am-g">
    <div class="am-u-lg-6 am-u-md-8 am-u-sm-centered">
        <br><br>
        <form method="post" class="am-form" action="<?php echo U('admin/login/check');?>">
            <label for="admin_name">Account:</label>
            <input type="text" class="am-form-field " name="username" id="admin_name" value="admin">
            <br>
            <label for="admin_password">Password:</label>
            <input type="password" class="am-form-field " name="password" id="admin_password" value="123456"><!---->

            <br/>
            <div class="am-cf">
                <input  type="button" onclick="usercheck()" value="Submit" class="am-btn am-btn-secondary am-btn-sm am-fl" >
                <input type="button" onclick="sendemail()"  value="Forget Password ?" class="am-btn am-btn-default am-btn-sm am-fr">
            </div>
        </form>
        <hr>

    </div>
</div>
<div class="am-modal am-modal-confirm" id='email_check' >
    <div class="am-modal-dialog">
        <div class="am-modal-hd">Please input you email</div>
        <div class="am-modal-bd">
          <label style="display:inline;">Email:</label>
          <input type="text" class="am-modal-prompt-input" style="width:300px;text-align:left;display:inline;border:1px solid #9C9898;" id="edit_BugID">
        </div>
        <div class="am-modal-footer">
            <span class="am-modal-btn" data-am-modal-confirm style="width: 50%;border:1px solid #cccccc;">OK</span>
            <span class="am-modal-btn" data-am-modal-cancel style="width: 50%;border:1px solid #cccccc;">Cancel</span>
        </div>
    </div>
</div>
<script type='text/javascript'>
    function usercheck() {
        var username=$("#admin_name").val();
        var password=$("#admin_password").val();
        $.post("<?php echo U('admin/login/check');?>",{username:username,password:password},function (data) {
            if(data=='success')
                    location.href="<?php echo U('admin/Index/index');?>";
            else
                    alert(data);
        });
    };
    function sendemail() {
        $("#email_check").modal({
            relatedTarget:this,
            onConfirm:function(e){
                $.post("<?php echo U('admin/login/send_email');?>",{email:e.data},function (data) {
                    alert(data);
                });
            },
            onCancel:function (e) {
                e.close()
            }
        });
    };
</script>
<script src="/qaweb/Public/assets/js/amazeui.min.js"></script>

</body>
</html>