<?php
return array(
	/*鏁版嵁搴撻厤缃� */
	'DB_TYPE'=>'mysql',   //璁剧疆鏁版嵁搴撶被鍨�?
	'DB_HOST'=>'localhost',//璁剧疆涓绘満
	'DB_NAME'=>'test',//璁剧疆鏁版嵁搴撳�?
	'DB_USER'=>'root',    //璁剧疆鐢ㄦ埛鍚峇A_user
	'DB_PWD'=>'',        //璁剧疆瀵嗙�?
	'DB_PORT'=>'3307',   //璁剧疆绔彛鍙�
	'DB_PREFIX'=>'go_',  //璁剧疆琛ㄥ墠缂�
);
